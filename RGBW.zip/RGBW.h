#include "Arduino.h"
#include "fastLED.h"

void RGBW_color( CRGB *leds  ,int led, int R, int G, int B, int W);
